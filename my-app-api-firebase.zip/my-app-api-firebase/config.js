// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCYurESrMwf2q-6KiutezlTiiWNYqk7PDM",
  authDomain: "booksappexam.firebaseapp.com",
  projectId: "booksappexam",
  storageBucket: "booksappexam.firebasestorage.app",
  messagingSenderId: "536911628363",
  appId: "1:536911628363:web:173b3591c0315deb46e5ce",
  measurementId: "G-KLPQMJ32YB"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);