import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

export default function BookList({ books }) {
  let totalPages = 0;
  for (let i = 0; i < books.length; i++) {
    totalPages += Number(books[i].pages);
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <Text style={styles.heading}>Books Collection</Text>
        <Text style={styles.total}>Total Pages: {totalPages}</Text>
      </View>

      {
        books.map((book) => (
          <View key={book.id} style={styles.card}>
            <Text style={styles.title}>{book.bookTitle}</Text>
            <Text>Author: {book.bookAuthor}</Text>
            <Text>Year: {book.publishYear}</Text>
            <Text>Pages: {book.pages}</Text>
          </View>
        )
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, gap: 12 },
  header: { marginBottom: 8 },
  heading: { fontSize: 20, fontWeight: 'bold', marginBottom: 4 },
  total: { fontSize: 16, fontWeight: '600' },
  muted: { opacity: 0.6 },
  card: {
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#f0f0f0',
  },
  title: { fontSize: 18, fontWeight: 'bold', marginBottom: 4 },
});